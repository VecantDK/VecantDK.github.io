#ifndef _CHESSMAN_H
#define _CHESSMAN_H
#include <bits/stdc++.h>
#include "chessboard.h"

namespace chessman
{
	int pawn_num[N << 1], cnt_pawn,
		knight_num[N << 1], cnt_knight,
		bishop_num[N << 1], cnt_bishop,
		rook_num[N << 1], cnt_rook,
		queen_num[N << 1], cnt_queen,
		king_num[3];
	namespace pawn
	{
		
		void init_pawn();
		bool can_normal(int _x1, int _y1, int _x2, int _y2);
		bool can_enp(int _x1, int _y1, int _x2, int _y2);
		void upgrade(int _x, int _y);
		bool can_go(int _x1, int _y1, int _x2, int _y2);
		void check_can(int _x, int _y);	//��ǿ��ߵ�
		void do_act(int _x, int _y);
	}
}
#endif
