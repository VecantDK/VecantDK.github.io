#ifndef CHESSBOARD_H_
#define CHESSBOARD_H_
#include <bits/stdc++.h>
#include <Windows.h>
#include "col_io.h"
#define pii std :: pair<node, node>

struct node {int x; int y;};
enum CHESSMAN_COLOR  {WHITE = 1, BLACK};
enum CHESSMAN_TYPE   {NONE, PAWN, KNIGHT, BISHOP, ROOK, QUEEN, KING};
enum CHESSBOARD_TYPE {INIT, FEND, DONE};

void  init_chessboard();
void print_chessboard();

const int N = 10;
const char axis_white_x[N] = {' ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'},
		   axis_white_y[N] = {' ', '8', '7', '6', '5', '4', '3', '2', '1'},
		   axis_black_x[N] = {' ', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'},
		   axis_black_y[N] = {' ', '1', '2', '3', '4', '5', '6', '7', '8'};
const int temp_mp[N][N]	= {{},
						   {NONE, - ROOK  , - KNIGHT, - BISHOP, - QUEEN , - KING  , - BISHOP, - KNIGHT, - ROOK},
						   {NONE, - PAWN  , - PAWN  , - PAWN  , - PAWN  , - PAWN  , - PAWN  , - PAWN  , - PAWN},
						   {}, {}, {}, {}, 
						   {NONE,   PAWN  ,   PAWN  ,   PAWN  ,   PAWN  ,   PAWN  ,   PAWN  ,   PAWN  ,   PAWN},
						   {NONE, ROOK    ,   KNIGHT,   BISHOP,   QUEEN ,   KING  ,   BISHOP,   KNIGHT,   ROOK}};   
std :: string change_print[N] = {"", "��", "��", "��", "��", "��", "��"}; 

int mp[N][N];
pii last_step;

void init_chessboard()
{
	for (int i = 1; i <= 8; i++)
		for (int j = 1; j <= 8; j++)
			mp[i][j] = temp_mp[i][j];
	last_step = std :: make_pair((node){0, 0}, (node){0, 0});
}

//TBD: ״̬: ��ʼ; ��ָ����� Ѱ�����; �Ѿ�����, ��ʾ��һ��. ��enum: CHESSBOARD_TYPE 
void print_chessboard()
{
	for (int i = 1; i <= 8; i++)
	{
		colio :: col_putchar(96, axis_white_y[i]); colio :: col_putchar(96, ' ');
		for (int j = 1; j <= 8; j++)
		{
			if (!mp[i][j]) colio :: col_puts(96, "  ");
			else if (mp[i][j] > 0) colio :: col_puts(96, change_print[abs(mp[i][j])]);
			else colio :: col_puts(111, change_print[abs(mp[i][j])]);
			colio :: col_putchar(96, ' ');
		}
		colio :: col_puts(96, "                ");
		colio :: col_putchar(96, axis_black_y[i]); colio :: col_putchar(96, ' ');
		for (int j = 1; j <= 8; j++)
		{
			if (!mp[9 - i][9 - j]) colio :: col_puts(96, "  ");
			else if (mp[9 - i][9 - j] > 0) colio :: col_puts(96, change_print[abs(mp[9 - i][9 - j])]);
			else colio :: col_puts(111, change_print[abs(mp[9 - i][9 - j])]);
			colio :: col_putchar(96, ' ');
		}
		puts("");
	}
	colio :: col_puts(96, "  ");
	for (int i = 1; i <= 8; i++) colio :: col_putchar(96, axis_white_x[i]), colio :: col_puts(96, "  ");
	colio :: col_puts(96, "                  ");
	for (int i = 1; i <= 8; i++) colio :: col_putchar(96, axis_black_x[i]), colio :: col_puts(96, "  ");
	puts("\n           �׷�                                      �ڷ�");
}
#endif
