#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
#include <Windows.h>
#include <conio.h>
#include "chessboard.h"
using namespace std;
using colio::col_print;

void init_game()
{
	init_chessboard();
}
int main(int argc, char** argv)
{
	init_game();
	print_chessboard();
	return 0;
}
