## $\mathcal{CHESS}$ $\text v1.0$ by $\large\texttt{VecantDK/}$$\textit{\textbf {Poussiere}}$

### 引用声明

- `col_io.h` ：部分来源于 [c语言 不定参数printf的实现](https://blog.csdn.net/tiantangmoke/article/details/102680709)，[C/C++ 控制台输出彩色文本（改变局部字体的颜色）](https://blog.csdn.net/qq_42885747/article/details/103835671)

### 开发日志

- `Jul. 31st,2024` 完成头文件 `col_io.h`，即彩色输出模块。