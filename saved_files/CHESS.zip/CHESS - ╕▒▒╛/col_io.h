#ifndef COL_IO_H_
#define COL_IO_H_
#include <bits/stdc++.h>
#include <Windows.h>
typedef char *  va_list;
#define _INTSIZEOF(n)   ( (sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1) ) 
#define va_start(ap,v)  ( ap = (va_list)&v + _INTSIZEOF(v) )   
#define va_end(ap)      ( ap = (va_list)0 )
namespace colio
{
	static char* __itoa(int num, char* str, int radix)
	{
		char index[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		unsigned unum;
		int i = 0, j, k;
		if(radix == 10 && num < 0)
			unum = (unsigned)-num, str[i++] = '-';
		else
			unum = (unsigned)num;
		do
			str[i++] = index[unum % (unsigned)radix], unum /= radix;
		while(unum);
		str[i] = '\0';
		k = (str[0] == '-' ? 1 : 0);
		char temp;
		for(j = k; j <= (i - 1) >> 1;j++)
			temp = str[j], str[j] = str[i - 1 + k - j], str[i - 1 + k - j] = temp;
		return str;
	}
	static uint8_t load_c(char *str, uint8_t offset, char c)
	{
		* (str + offset) = c;
		offset++;
		return offset;
	}
	static uint8_t load_data(char *str, uint8_t offset, uint32_t data)
	{
		char datastr[17] = {0};
		__itoa(data, datastr, 10);
		uint8_t len = strlen(datastr);
		for(uint8_t i = 0; i < len; i++)
			* (str + offset) = datastr[i], offset++;
		return offset;
	}
	static uint8_t load_fdata(char *str, uint8_t offset, uint32_t data)
	{
	  char datastr[17] = {0};
		__itoa(data, datastr, 10);
		uint8_t len = strlen(datastr);
		if(len == 1)
			* (str + offset++) = datastr[0],
			* (str + offset++) = '.',
			* (str + offset++) = '0';
		else if(len > 1)
				for(uint8_t i = 0; i < len; i ++)
				{
					* (str + offset++) = datastr[i];
					if( i == (len - 2))
					 * (str + offset++)  = '.';
				}
	  return offset;
	}
	static uint8_t load_string(char *str, uint8_t offset , char *addstr)
	{
		uint8_t len = strlen(addstr);
		for(uint8_t i = 0; i < len; i ++)
			* (str + offset) = addstr[i], offset++;
		return offset;
	}
	int col_print(int print_color, const char *fmt, ...) 
	{
		
		char str[1100] = {0};
		uint8_t offset = 0;
		va_list ap;
		va_start(ap, fmt); 
		for(; *fmt != '\0'; fmt++)
		{
			if (*fmt != '%')
			{
				offset = load_c(str,offset,*fmt);
				continue;
			}
			fmt++;
			switch(*fmt)
			{
				case 'u': offset = load_data(str, offset, va_arg(ap, unsigned int)); break;
				case 's': offset = load_string(str, offset, va_arg(ap, char *)); break;
				case 'f': offset = load_fdata(str, offset, va_arg(ap, unsigned int)); break;
				default: offset = load_c(str, offset, *fmt); break;
			}
			if(offset >= 100) break;
		}
		va_end(ap);
		HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | print_color);
		std :: cout<<str;
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | 7);
		return 0;
	}
	int col_puts(int print_color, std :: string str)
	{
		HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | print_color);
		std :: cout<<str;
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | 7);
	}
	int col_putchar(int print_color, char ch)
	{
		HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | print_color);
		std :: cout<<ch;
		SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | 7);	
	}
}
#endif
